from fastapi import FastAPI
from pydantic import BaseModel
from langchain_ollama import OllamaLLM
from langchain_core.prompts import ChatPromptTemplate
from fastapi.middleware.cors import CORSMiddleware

# Charger la base de connaissances
def load_knowledge_base(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()

knowledge_base = load_knowledge_base('knowledge_base.txt')

# Modèle et template
template = """
you are my helpful assistant. use the provided knowledge base to answer questions accurately. 
if you do not find the answer in the knowledge base, do not invent an answer. instead, respond with:
"sorry, i am not allowed to reply."

knowledge base:
{knowledge_base}

conversation history:
{context}

question: {question}
answer:
"""
model = OllamaLLM(model="stablelm-zephyr")
prompt = ChatPromptTemplate.from_template(template)
chain = prompt | model

# Stockage du contexte utilisateur
conversation_context = {}

# Définir l'application FastAPI
app = FastAPI()

origins = [
    "http://localhost:3000",  # React en local
    "http://localhost:5173",  # Vite.js en local
    "http://127.0.0.1:3000",  # React en local sur IP
    "http://127.0.0.1:5173",  # Vite.js en local sur IP
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],  # Autorise toutes les méthodes HTTP
    allow_headers=["*"],  # Autorise tous les headers
)


# Modèle de données pour les requêtes et réponses
class ChatRequest(BaseModel):
    question: str

class ChatResponse(BaseModel):
    response: str

@app.post("/chatbot", response_model=ChatResponse)
async def chatbot(request: ChatRequest):
    # ID utilisateur par défaut (pas d'authentification nécessaire)
    user_id = "anonymous_user"

    # Initialiser le contexte utilisateur si nécessaire
    if user_id not in conversation_context:
        conversation_context[user_id] = ""

    # Générer une réponse
    context = conversation_context[user_id]
    result = chain.invoke({
        "context": context,
        "question": request.question,
        "knowledge_base": knowledge_base
    })

    if "sorry, i am not allowed to reply" in result.lower():
        response = "sorry, i am not allowed to reply."
    else:
        response = result
        conversation_context[user_id] += f"\nuser: {request.question}\nai: {response}"

    return ChatResponse(response=response)
